"use client";
import { useState, useMemo } from "react";
import dados from "@/lib/data/trafegoDashboard.json";

type Zona = (typeof dados.zonas)[0];

// interpola entre verde (baixo) → amarelo (médio) → vermelho (alto)
function fluxoParaCor(valor: number): string {
  const v = Math.min(100, Math.max(0, valor));
  if (v < 40) {
    const t = v / 40;
    const r = Math.round(20 + t * (220 - 20));
    const g = Math.round(180 + t * (210 - 180));
    const b = Math.round(20 + t * (20 - 20));
    return `rgb(${r},${g},${b})`;
  } else if (v < 70) {
    const t = (v - 40) / 30;
    const r = Math.round(220 + t * (240 - 220));
    const g = Math.round(210 - t * (210 - 160));
    const b = 20;
    return `rgb(${r},${g},${b})`;
  } else {
    const t = (v - 70) / 30;
    const r = Math.round(240 - t * (240 - 200));
    const g = Math.round(160 - t * (160 - 30));
    const b = 20;
    return `rgb(${r},${g},${b})`;
  }
}

function fluxoParaLabel(valor: number): string {
  if (valor < 30) return "Baixo";
  if (valor < 60) return "Moderado";
  if (valor < 80) return "Alto";
  return "Crítico";
}

const municipios = ["Todos", ...Array.from(new Set(dados.zonas.map((z) => z.municipio)))];

export default function TrafegoDashboard() {
  const [municipioAtivo, setMunicipioAtivo] = useState("Todos");
  const [diaAtivo, setDiaAtivo] = useState(0); // índice do dia da semana
  const [zonaDetalhada, setZonaDetalhada] = useState<Zona | null>(null);
  const [celulaHover, setCelulaHover] = useState<{ zona: string; horario: string; valor: number } | null>(null);

  const zonasFiltradas = useMemo(
    () =>
      municipioAtivo === "Todos"
        ? dados.zonas
        : dados.zonas.filter((z) => z.municipio === municipioAtivo),
    [municipioAtivo]
  );

  // média de fluxo por horário no dia selecionado
  const mediaHorarios = useMemo(() => {
    return dados.horarios.map((_, hi) => {
      const valores = zonasFiltradas.map((z) => z.fluxo[diaAtivo][hi]);
      return Math.round(valores.reduce((a, b) => a + b, 0) / valores.length);
    });
  }, [zonasFiltradas, diaAtivo]);

  const horaRushIdx = mediaHorarios.indexOf(Math.max(...mediaHorarios));
  const mediaGeral = Math.round(mediaHorarios.reduce((a, b) => a + b, 0) / mediaHorarios.length);

  return (
    <div className="relative z-10 min-h-screen text-foreground">
      <div className="mx-auto max-w-5xl px-4 py-10">

        {/* cabeçalho */}
        <div className="mb-2">
          <p className="text-eyebrow">Vísent · Vitta Carreira</p>
          <h1 className="text-display mt-1 text-[clamp(1.6rem,4vw,2.2rem)]">
            Tráfego Urbano — RM de Florianópolis
          </h1>
          <p className="mt-1 font-sans text-xs text-foreground-muted">
            Atualizado em {new Date(dados.meta.atualizacao).toLocaleString("pt-BR")} · Fonte: {dados.meta.fonte}
          </p>
        </div>

        {/* filtros */}
        <div className="mt-6 flex flex-wrap gap-4">
          {/* município */}
          <div>
            <p className="field-label mb-2">Município</p>
            <div className="flex flex-wrap gap-2">
              {municipios.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMunicipioAtivo(m)}
                  className={`rounded-full border px-3 py-1 font-sans text-xs uppercase tracking-wider transition-colors ${
                    municipioAtivo === m
                      ? "border-accent bg-accent/15 text-foreground"
                      : "border-foreground-muted/20 bg-white/4 text-foreground-muted hover:border-foreground-muted/40"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* dia da semana */}
          <div>
            <p className="field-label mb-2">Dia da semana</p>
            <div className="flex gap-1">
              {dados.dias.map((dia, i) => (
                <button
                  key={dia}
                  type="button"
                  onClick={() => setDiaAtivo(i)}
                  className={`rounded-lg border px-3 py-1.5 font-sans text-xs transition-colors ${
                    diaAtivo === i
                      ? "border-accent bg-accent/15 text-foreground"
                      : "border-foreground-muted/20 bg-white/4 text-foreground-muted hover:border-foreground-muted/40"
                  }`}
                >
                  {dia}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* cards de resumo */}
        <div className="mt-6 grid grid-cols-3 gap-3">
          <div className="feature-card text-center">
            <p className="text-[1.6rem] font-bold text-foreground">{zonasFiltradas.length}</p>
            <p className="field-label mt-1 text-center">Zonas monitoradas</p>
          </div>
          <div className="feature-card text-center">
            <p className="text-[1.6rem] font-bold" style={{ color: fluxoParaCor(mediaGeral) }}>
              {mediaGeral}%
            </p>
            <p className="field-label mt-1 text-center">Fluxo médio</p>
          </div>
          <div className="feature-card text-center">
            <p className="text-[1.6rem] font-bold text-accent">{dados.horarios[horaRushIdx]}</p>
            <p className="field-label mt-1 text-center">Horário de pico</p>
          </div>
        </div>

        {/* mapa de calor */}
        <div className="feature-card mt-6 overflow-x-auto">
          <p className="field-label mb-4">Concentração de fluxo por zona e horário</p>

          <table className="w-full min-w-[560px] border-separate border-spacing-1">
            <thead>
              <tr>
                <th className="pb-2 text-left font-sans text-[0.65rem] uppercase tracking-wider text-foreground-muted">
                  Zona
                </th>
                {dados.horarios.map((h) => (
                  <th key={h} className="pb-2 font-sans text-[0.65rem] uppercase tracking-wider text-foreground-muted">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {zonasFiltradas.map((zona) => (
                <tr key={zona.id}>
                  <td className="pr-3 font-sans text-xs text-foreground-muted whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => setZonaDetalhada(zonaDetalhada?.id === zona.id ? null : zona)}
                      className="text-left hover:text-foreground transition-colors"
                    >
                      <span className="block font-bold text-foreground">{zona.nome}</span>
                      <span className="text-[0.6rem]">{zona.municipio}</span>
                    </button>
                  </td>
                  {zona.fluxo[diaAtivo].map((valor, hi) => (
                    <td key={hi} className="text-center">
                      <div
                        className="relative mx-auto h-8 w-8 cursor-pointer rounded-lg transition-transform hover:scale-110"
                        style={{ backgroundColor: fluxoParaCor(valor), opacity: 0.85 }}
                        onMouseEnter={() =>
                          setCelulaHover({ zona: `${zona.nome} — ${dados.horarios[hi]}`, horario: dados.horarios[hi], valor })
                        }
                        onMouseLeave={() => setCelulaHover(null)}
                        title={`${zona.nome} · ${dados.horarios[hi]}: ${valor}% (${fluxoParaLabel(valor)})`}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>

          {/* legenda */}
          <div className="mt-4 flex items-center gap-3">
            <span className="font-sans text-[0.65rem] text-foreground-muted">Baixo</span>
            <div className="flex h-3 flex-1 overflow-hidden rounded-full" style={{
              background: "linear-gradient(to right, rgb(20,180,20), rgb(240,160,20), rgb(200,30,20))"
            }} />
            <span className="font-sans text-[0.65rem] text-foreground-muted">Crítico</span>
          </div>

          {/* tooltip hover */}
          {celulaHover && (
            <div className="mt-3 rounded-xl border border-foreground-muted/20 bg-white/6 px-4 py-2 font-sans text-sm">
              <span className="font-bold text-foreground">{celulaHover.zona}</span>
              <span className="mx-2 text-foreground-muted">·</span>
              <span style={{ color: fluxoParaCor(celulaHover.valor) }}>
                {celulaHover.valor}% — {fluxoParaLabel(celulaHover.valor)}
              </span>
            </div>
          )}
        </div>

        {/* detalhe da zona selecionada */}
        {zonaDetalhada && (
          <div className="feature-card mt-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="field-label">Detalhe da zona</p>
                <h2 className="text-display text-[1.2rem]">
                  {zonaDetalhada.nome} · {zonaDetalhada.municipio}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setZonaDetalhada(null)}
                className="font-sans text-foreground-muted hover:text-foreground"
              >
                ✕
              </button>
            </div>

            {/* mini gráfico de barras por horário no dia selecionado */}
            <div className="flex items-end gap-2">
              {zonaDetalhada.fluxo[diaAtivo].map((v, hi) => (
                <div key={hi} className="flex flex-1 flex-col items-center gap-1">
                  <span className="font-sans text-[0.6rem] text-foreground-muted">{v}%</span>
                  <div
                    className="w-full rounded-t-md transition-all duration-500"
                    style={{
                      height: `${Math.max(6, Math.round((v / 100) * 80))}px`,
                      backgroundColor: fluxoParaCor(v),
                      opacity: 0.85,
                    }}
                  />
                  <span className="font-sans text-[0.6rem] text-foreground-muted">{dados.horarios[hi]}</span>
                </div>
              ))}
            </div>

            {/* comparativo entre dias */}
            <p className="field-label mt-5 mb-3">Fluxo médio diário</p>
            <div className="flex items-end gap-2">
              {dados.dias.map((dia, di) => {
                const media = Math.round(
                  zonaDetalhada.fluxo[di].reduce((a, b) => a + b, 0) / zonaDetalhada.fluxo[di].length
                );
                return (
                  <div key={dia} className="flex flex-1 flex-col items-center gap-1">
                    <span className="font-sans text-[0.6rem] text-foreground-muted">{media}%</span>
                    <div
                      className={`w-full rounded-t-md transition-all duration-500 ${di === diaAtivo ? "ring-1 ring-accent" : ""}`}
                      style={{
                        height: `${Math.max(6, Math.round((media / 100) * 60))}px`,
                        backgroundColor: fluxoParaCor(media),
                        opacity: di === diaAtivo ? 1 : 0.6,
                      }}
                    />
                    <span className={`font-sans text-[0.6rem] ${di === diaAtivo ? "text-accent" : "text-foreground-muted"}`}>
                      {dia}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
